#ifndef CIRCLEVISION_H
#define CIRCLEVISION_H

#include <QGraphicsEllipseItem>

class circleVision
{
public:
    circleVision();
};

#endif // CIRCLEVISION_H
