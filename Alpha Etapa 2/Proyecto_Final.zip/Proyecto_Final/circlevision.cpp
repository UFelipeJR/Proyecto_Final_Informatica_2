#include "circlevision.h"

circleVision::circleVision()
{
    qDebug() << "jeje";
}
